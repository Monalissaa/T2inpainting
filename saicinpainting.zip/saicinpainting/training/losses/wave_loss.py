from saicinpainting.training.modules.wave import WavePool

class WaveLoss:
    def __init__(self, loss_type, frequency) -> None:
        if loss_type=='l1':
        
        elif loss_type=='l2':

        elif loss_type=='segm_pl':
            